﻿/* Exemplary file for Chapter 2 - Arrays and Lists. */

namespace SimpleLists02
{
    public class Person
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public CountryEnum Country { get; set; }
    }
}
