﻿/* Exemplary file for Chapter 2 - Arrays and Lists. */

namespace SimpleLists02
{
    public enum CountryEnum
    {
        PL,
        UK,
        DE
    }
}
