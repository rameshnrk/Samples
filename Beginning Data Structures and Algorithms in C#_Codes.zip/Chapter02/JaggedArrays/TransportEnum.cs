﻿/* Exemplary file for Chapter 2 - Arrays and Lists. */

namespace JaggedArrays
{
    public enum TransportEnum
    {
        CAR,
        BUS,
        SUBWAY,
        BIKE,
        WALK
    }
}
