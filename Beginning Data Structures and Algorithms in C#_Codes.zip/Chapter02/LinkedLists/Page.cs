﻿/* Exemplary file for Chapter 2 - Arrays and Lists. */

using System;

namespace LinkedLists
{
    public class Page
    {
        public string Content { get; set; }
    }
}
