﻿/* Exemplary file for Chapter 2 - Arrays and Lists. */

namespace SortedLists
{
    public enum CountryEnum
    {
        PL,
        UK,
        DE
    }
}
