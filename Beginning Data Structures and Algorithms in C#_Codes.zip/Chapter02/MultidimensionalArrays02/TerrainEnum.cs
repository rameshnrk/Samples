﻿/* Exemplary file for Chapter 2 - Arrays and Lists. */

namespace MultiDimensionalArrays02
{
    public enum TerrainEnum
    {
        GRASS,
        SAND,
        WATER,
        WALL
    }
}
