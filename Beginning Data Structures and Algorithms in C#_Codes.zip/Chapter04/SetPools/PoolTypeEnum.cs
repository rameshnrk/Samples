﻿/* Exemplary file for Chapter 4 - Dictionaries and Sets. */

namespace SetPools
{
    public enum PoolTypeEnum
    {
        RECREATION,
        COMPETITION,
        THERMAL,
        KIDS
    };
}
