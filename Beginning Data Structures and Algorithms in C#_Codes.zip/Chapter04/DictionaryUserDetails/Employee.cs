﻿/* Exemplary file for Chapter 4 - Dictionaries and Sets. */

namespace DictionaryUserDetails
{
    public class Employee
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string PhoneNumber { get; set; }
    }
}
