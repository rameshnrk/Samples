﻿/* Exemplary file for Chapter 5 - Variants of Trees. */

namespace Trees
{
    public enum TraversalEnum
    {
        PREORDER,
        INORDER,
        POSTORDER
    }
}