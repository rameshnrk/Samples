﻿/* Exemplary file for Chapter 5 - Variants of Trees. */

using System;

namespace Trees
{
    public class Tree<T>
    {
        public TreeNode<T> Root { get; set; }
    }
}
