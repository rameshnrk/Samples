﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TheBookStore.Client
{
    public class BookItem
    {
        public int id { get; set; }
        public string title { get; set; }
        public string authors { get; set; }
    }
}